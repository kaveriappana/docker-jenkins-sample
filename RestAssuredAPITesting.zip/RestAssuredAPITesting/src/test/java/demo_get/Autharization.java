package demo_get;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.testng.annotations.Test;

public class Autharization {

    @Test

    public void get_AccessToken()

    {

        String url = "https://api.us.onelogin.com/auth/oauth2/v2/token";

        RequestSpecification http_req = RestAssured.given()

                .queryParam("access_token", "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")

                .header("Content-Type", "application/json");

        Response response = http_req.get(url);

        int status_code = response.getStatusCode();

        String response_body = response.asString();

        System.out.println("------status code-----" +status_code);
        System.out.println("----response body------" +response_body);

    }

}
