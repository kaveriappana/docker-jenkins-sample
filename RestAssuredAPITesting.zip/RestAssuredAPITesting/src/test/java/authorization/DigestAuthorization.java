package authorization;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;
import io.restassured.specification.RequestSpecification;

public class DigestAuthorization {
    @Test
    public void getUserData() {
        RequestSpecification httpRequest = RestAssured.given().auth().digest("postman", "password");
        Response response = httpRequest.get("https://postman-echo.com/basic-auth");
        ResponseBody body = response.body();
        String responseBody = body.asString();
        System.out.println("Response Body Is "+responseBody);
    }
}