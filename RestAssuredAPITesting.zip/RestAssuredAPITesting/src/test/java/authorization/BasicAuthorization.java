package authorization;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;
import io.restassured.specification.RequestSpecification;

public class BasicAuthorization {
    @Test
    public void getUserData() {
        //Using the preemptive directive of basic auth to send credentials to the server
        RequestSpecification httpRequest = RestAssured.given().auth().preemptive().basic("postman", "password");
        Response response = httpRequest.get("https://postman-echo.com/basic-auth");
        ResponseBody body = response.body();
        String responseBody = body.asString();
        System.out.println("Response Body Is "+responseBody);
    }
}