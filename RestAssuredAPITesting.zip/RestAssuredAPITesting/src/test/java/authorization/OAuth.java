package authorization;

import org.testng.Assert;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;
import io.restassured.specification.RequestSpecification;

public class OAuth {
    @Test
    public void getUserData() {
        RequestSpecification httpRequest = RestAssured.given().auth().oauth2("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");
        Response response = httpRequest.get("https://api.github.com/user/repos");
        ResponseBody body = response.body();
        String responseBody = body.asString();
        System.out.println("Response Body Is "+responseBody);
        int statusCode = response.getStatusCode();
        System.out.println("Status code is " +statusCode);
        Assert.assertEquals(statusCode, 200);
    }
}