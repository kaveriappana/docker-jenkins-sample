package datadriventesting;

import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.json.simple.JSONObject;
import org.testng.Assert;
import org.testng.annotations.*;

import java.io.IOException;

public class DataDrivenTesting {
    @Test(dataProvider = "empdataprovider")
    void createNewRecord(String ename, String eage, String esal)
    {
        //base URI
        RestAssured.baseURI = "https://dummy.restapiexample.com";

        //Request object
        RequestSpecification httpRequest = RestAssured.given();

        //sending request
        JSONObject requestParams = new JSONObject();

        requestParams.put("name",ename);
        requestParams.put("age",eage);
        requestParams.put("salary",esal);

        httpRequest.header("Content-Type","application/json");
        httpRequest.body(requestParams.toJSONString()); //attach above data to request

        //Response object
        Response response = httpRequest.request(Method.POST,"/api/v1/create");

        //print response
        String responseBody = response.getBody().asString();
        System.out.println("Response body is " +responseBody);

        //Assert.assertEquals(responseBody.contains(ename),true);
        //Assert.assertEquals(responseBody.contains(eage),true);
        //Assert.assertEquals(responseBody.contains(esal),true);

        //status code validation
        int statusCode = response.getStatusCode();
        System.out.println("Status code is " +statusCode);
        Assert.assertEquals(statusCode, 200);

        //Status validation
        //String status = response.jsonPath().get("status");
        //System.out.println("status is " +status);
        //Assert.assertEquals(status,"success");

        //message validation
        //String message = response.jsonPath().get("message");
        //System.out.println("message is " +message);
        //Assert.assertEquals(message,"Successfully! Record has been added.");

    }

    @DataProvider(name = "empdataprovider")
    @Test(retryAnalyzer = RetryAnalyzer.class)
    String[][] getEmpData() throws IOException
    {
        String path = "C:\\Users\\Ashish.Eerapuram\\IdeaProjects\\RestAssuredAPITesting\\src\\test\\resources\\excelDataDataDriven.xlsx";
        int rownum = XLUtils.getRowCount(path,"Sheet1");
        int colcount = XLUtils.getCellCount(path, "Sheet1",1);
        String empdata[][] = new String[rownum][colcount];
        for(int i = 1; i <= rownum; i++)
        {
            for (int j =0 ; j < colcount; j++ )
            {
                empdata[i-1][j] = XLUtils.getCellData(path, "Sheet1", i, j);
            }
        }
        //String empdata[][] = {{"ABCXYZ123","10000","25"},{"ABCXYZ456","20000","30"},{"ABCXYZ789","30000","35"}};
        return(empdata);
    }

}